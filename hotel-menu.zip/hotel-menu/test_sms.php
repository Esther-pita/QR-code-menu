<?php
require('../auth_session.php');
require('../db.php');
require('../vendor/autoload.php');

use AfricasTalking\SDK\AfricasTalking;

$username = "nafuu";
$apiKey = "1889bf0b8130f41c44513e620546b1533646f8c575eda8dcc554f2df68561b9c";

$AT = new AfricasTalking($username, $apiKey);
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    $task_name = stripslashes($_POST['name']);
    $task_name = mysqli_real_escape_string($con, $task_name);

    $due_date = stripslashes($_POST['due_date']);
    $due_date = mysqli_real_escape_string($con, $due_date);

    $worker_id = stripslashes($_POST['worker_id']);
    $worker_id = mysqli_real_escape_string($con, $worker_id);

    // Fetch worker's information from the database
    $sql = "SELECT username, phone_number FROM users WHERE id = '$worker_id'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $worker_username = $row['username'];
        $worker_phone_number = $row['phone_number'];

        // Send an SMS to the worker
        $sms = $AT->sms();

        $data = $sms->send([
            'to' => $worker_phone_number,
            'message' => 'Hello ' . $worker_username .
                ', you have been assigned a new task: '
                . $task_name .
                'Please log in to your dashboard and view the task.'
        ]);

        // Insert the task into the tasks table
        $query = "INSERT INTO `tasks` (task_name, due_date, worker_id) VALUES ('$task_name', '$due_date', '$worker_id')";
        $result = mysqli_query($con, $query);

        if ($result) {
            header("Location: payments.php");
        } else {
            echo "An issue occurred with allocating a task!";
        }
    } else {
        echo "Worker not found in the database.";
    }
}
?>
