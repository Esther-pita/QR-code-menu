<?php
header("Location: landingpage.php");
?>
