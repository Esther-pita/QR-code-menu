<?php
require('db.php');
session_start();

$_SESSION['success'] = "";

if (isset($_POST['username'])) {
    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);

    $query = "SELECT * FROM `users` WHERE username='$username' AND password='" . md5($password) . "'";
    $result = mysqli_query($con, $query) or die(mysql_error());
    $rows = mysqli_num_rows($result);

    if ($rows == 1) {
        $user_data = mysqli_fetch_assoc($result);

        // Storing user ID in session variable
        $_SESSION['user_id'] = $user_data['id'];

        // Welcome message
        $_SESSION['success'] = "You have logged in!";

        // Check user type and redirect accordingly
        if ($user_data['type'] === 'user') {
            header("Location: user/dashboard.php");
        }  elseif ($user_data['type'] === 'admin') {
            header("Location: admin/dashboard.php");
        } else {
            echo "<div class='form'>
                <h3>Invalid user type.</h3><br/>
                <p class='link'>Click here to <a href='signin.html'>Login</a> again.</p>
                </div>";
        }
    } else {
        echo "<div class='form'>
            <h3>Incorrect Username/password.</h3><br/>
            <p class='link'>Click here to <a href='signin.html'>Login</a> again.</p>
            </div>";
    }
}
?>
