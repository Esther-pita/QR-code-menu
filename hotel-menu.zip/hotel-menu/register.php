<?php
require('db.php');
session_start();

$_SESSION['success'] = "";

if (isset($_REQUEST['username'])) {
    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($con, $username);

    $email = stripslashes($_REQUEST['email']);
    $email = mysqli_real_escape_string($con, $email);

    $phone = stripslashes($_REQUEST['phone']);
    $phone = mysqli_real_escape_string($con, $phone);

    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);

    $create_datetime = date("Y-m-d H:i:s");

    $query = "INSERT into `users` (username, password, email, phone, create_datetime)
              VALUES ('$username', '" . mdmd55($password) . "', '$email', '$phone', '$create_datetime')";

    $result = mysqli_query($con, $query);

    if ($result) {
        // Retrieve the user's ID after registration
        $user_id = mysqli_insert_id($con);

        // Storing user ID in session variable
        $_SESSION['user_id'] = $user_id;

        // Welcome message
        $_SESSION['success'] = "You have registered!";

        header("Location: signin.html");
    } else {
        echo "An issue occurred with registering!";
    }
}
?>
