<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Admin area</title>
    <link rel="stylesheet" href="../style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <?php include 'header.php'; ?>
    <!-- End Header -->

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>Admin Dashboard</h2>
        </div>

        <div class="main-cards">

            <?php
            include ('../db.php');

            $cards = [
                [
                    'title' => 'Users',
                    'icon' => 'groups',
                    'table' => 'users',
                ],
                [
                    'title' => 'Menu Items',
                    'icon' => 'request_quote',
                    'table' => 'menu_items',
                ],
                [
                    'title' => 'Payments',
                    'icon' => 'notification_important',
                    'table' => 'payments',
                ],
            ];

            foreach ($cards as $card) {
                $query = "SELECT COUNT(*) AS count FROM " . $card['table'];
                $result = $con->query($query);

                if ($result) {
                    $row = $result->fetch_assoc();
                    $count = $row['count'];

                    echo '<div class="card">
                <a href="' . $card['table'] . '.php">
                    <div class="card-inner">
                        <h3 class="text-card">' . $card['title'] . '</h3>
                        <span class="material-icons-outlined icons">' . $card['icon'] . '</span>
                    </div>
                    <h1 class="text-num">' . $count . '</h1>
                </a>
              </div>';
                } else {
                    echo "Error: " . $con->error;
                }
            }

            $con->close();
            ?>


        </div>

    </main>
    <!-- End Main -->

</div>
<script src="../scripts.js"></script>
</body>
</html>
