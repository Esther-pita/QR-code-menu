<?php
require('../auth_session.php');
require('../db.php');
require '../vendor/autoload.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

if (isset($_REQUEST['table_id'])) {
    $tableId = stripslashes($_REQUEST['table_id']);
    $tableId = mysqli_real_escape_string($con, $tableId);

    // Generate the QR code
    $qrCode = QrCode::create('https://localhost/hotel-menu/landingpage.php?table=' . $tableId);

    $pngWriter = new PngWriter();
    $qrCodeResult = $pngWriter->write($qrCode);

    $qrCodeData = $qrCodeResult->getString();

    $insertQrCodeQuery = "INSERT INTO `qrcodes` (table_id, qr_code_data) VALUES (?, ?)";

    $stmt = mysqli_prepare($con, $insertQrCodeQuery);
    mysqli_stmt_bind_param($stmt, "ss", $tableId, $qrCodeData);

    $resultQrCodeInsert = mysqli_stmt_execute($stmt);

    if ($resultQrCodeInsert) {
        header("Location: qrcodes.php");
    } else {
        echo "An issue occurred with adding a new QR code!";
    }

    mysqli_stmt_close($stmt);
}
?>
