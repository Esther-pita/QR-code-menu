<?php
require('../auth_session.php');
require('../db.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);
if (isset($_REQUEST['name'])) {
    // removes backslashes
    $name = stripslashes($_REQUEST['name']);
    $name = mysqli_real_escape_string($con, $name);

    $query = "INSERT into `categories` (name) VALUES ('$name')";

    $result = mysqli_query($con, $query);

    if ($result) {
        header("Location: menu_category.php");
    } else {
        echo "An issue occurred with adding a new category!";
    }
}
?>