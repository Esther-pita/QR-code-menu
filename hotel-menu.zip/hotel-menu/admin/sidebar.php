<aside id="sidebar">
    <div class="sidebar-title">
        <div class="sidebar-brand text-card">
            <span class="material-icons-outlined">restaurant_menu</span> Digital Menu Eden Restaurant
        </div>
        <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
    </div>

    <ul class="sidebar-list">
        <li class="sidebar-list-item">
            <a href="dashboard.php">
                <span class="material-icons-outlined">dashboard</span> Dashboard
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="menu_category.php">
                <span class="material-icons-outlined">notification_important</span> Menu Category
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="menu_items.php">
                <span class="material-icons-outlined">engineering</span> Menu Items
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="users.php">
                <span class="material-icons-outlined">groups</span> User
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="qrcodes.php">
                <span class="material-icons-outlined">task</span> Generate QR Codes
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="payments.php">
                <span class="material-icons-outlined">task</span> Payments
            </a>
        </li>

        <li class="sidebar-list-item">
            <a href="logout.php">
                <span class="material-icons-outlined">logout</span> Logout
            </a>
        </li>
    </ul>
</aside>