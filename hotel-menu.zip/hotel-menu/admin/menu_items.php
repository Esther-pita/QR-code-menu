<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin - Menu Items</title>
    <link rel="stylesheet" href="css/style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
            <span class="material-icons-outlined text-card">menu</span>
        </div>
        <div class="header-left text-card">
            <span class="material-icons-outlined">search</span>
        </div>
        <div class="header-right text-card">
            <span class="material-icons-outlined">notifications</span>
            <span class="material-icons-outlined">email</span>
            <span class="material-icons-outlined">account_circle</span>
        </div>
    </header>
    <!-- End Header -->

    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="sidebar-title">
            <div class="sidebar-brand text-card">
                <span class="material-icons-outlined">restaurant_menu</span> Digital Menu Eden Restaurant
            </div>
            <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
            <li class="sidebar-list-item">
                <a href="dashboard.php">
                    <span class="material-icons-outlined">dashboard</span> Dashboard
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="menu_category.php">
                    <span class="material-icons-outlined">notification_important</span> Menu Category
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="menu_items.php">
                    <span class="material-icons-outlined">engineering</span> Menu Items
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="users.php">
                    <span class="material-icons-outlined">groups</span> User
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="qrcodes.php">
                    <span class="material-icons-outlined">task</span> Generate QR Codes
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="payments.php">
                    <span class="material-icons-outlined">task</span> Payments
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="logout.php">
                    <span class="material-icons-outlined">logout</span> Logout
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>Menu Items</h2>

            <a href="add_menu_item.php">
                <button class="completebtn">
                    Add Menu Items
                </button>
            </a>
        </div>

        <div class="table-container">
            <table class="content-table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Category</th>
                </tr>
                </thead>
                <tbody>
                <?php
                include("../db.php");
                include("../auth_session.php");


                $query = "SELECT menu_items.id, menu_items.name, menu_items.price, categories.name AS category_name
         FROM menu_items
          LEFT JOIN categories ON menu_items.category_id = categories.id";
                $resultMenu = mysqli_query($con, $query);

                if (mysqli_num_rows($resultMenu) > 0) {
                    // Output each menu item as a table row
                    while ($row = mysqli_fetch_assoc($resultMenu)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['price'] . "</td>";
                        echo "<td>" . $row['category_name'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No items found.</td></tr>";
                }

                // Close the database connection
                mysqli_close($con);
                ?>
                </tbody>
            </table>
        </div>

    </main>
    <!-- End Main -->

</div>
<script src="js/scripts.js"></script>
</body>
</html>
`