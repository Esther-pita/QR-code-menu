<?php
require('../auth_session.php');
require('../db.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {

    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        print_r($_FILES);
        $image = $_FILES['image']['tmp_name'];
        $imgContent = file_get_contents($image);

    } else {
        echo "Please select an image file to upload.";
    }

    $item_name = stripslashes($_POST['name']);
    $item_name = mysqli_real_escape_string($con, $item_name);

    $description = stripslashes($_POST['description']);
    $description = mysqli_real_escape_string($con, $description);

    $price = stripslashes($_POST['price']);
    $price = mysqli_real_escape_string($con, $price);



    $category_id = stripslashes($_POST['category_id']);
    $category_id = mysqli_real_escape_string($con, $category_id);

    $sql = "SELECT id, name FROM categories WHERE id = '$category_id'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {


        $query = "INSERT INTO `menu_items` (name, description, price, category_id, image_url) 
          VALUES (?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "ssdss", $item_name, $description, $price, $category_id, $imgContent);

        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            header("Location: menu_items.php");
        } else {
            echo "Error: " . mysqli_error($con);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($con);
    } else {
        echo "Categories not found in the database.";
    }
}
?>
