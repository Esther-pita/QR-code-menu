<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin - Add Category</title>
    <link rel="stylesheet" href="css/style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
            <span class="material-icons-outlined text-card">menu</span>
        </div>
        <div class="header-left text-card">
            <span class="material-icons-outlined">search</span>
        </div>
        <div class="header-right text-card">
            <span class="material-icons-outlined">notifications</span>
            <span class="material-icons-outlined">email</span>
            <span class="material-icons-outlined">account_circle</span>
        </div>
    </header>
    <!-- End Header -->

    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="sidebar-title">
            <div class="sidebar-brand text-card">
                <span class="material-icons-outlined">restaurant_menu</span> Digital Menu Eden Restaurant
            </div>
            <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
            <li class="sidebar-list-item">
                <a href="dashboard.php">
                    <span class="material-icons-outlined">dashboard</span> Dashboard
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="menu_category.php">
                    <span class="material-icons-outlined">category</span> Menu Category
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="menu_items.php">
                    <span class="material-icons-outlined">engineering</span> Menu Items
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="users.php">
                    <span class="material-icons-outlined">groups</span> User
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="qrcodes.php">
                    <span class="material-icons-outlined">task</span> Generate QR Codes
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="payments.php">
                    <span class="material-icons-outlined">task</span> Payments
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="logout.php">
                    <span class="material-icons-outlined">logout</span> Logout
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>Add Category</h2>
        </div>

        <div class="container">
            <input type="checkbox" id="check">
            <div class="login form"><br>
                <form action="add_category_logic.php" method="post">
                    <input type="text"  name="name" placeholder="Name" required />
                    <input type="submit" name="submit" value="Add Category" >
                </form>

            </div>

        </div>

    </main>
    <!-- End Main -->

</div>
<script src="js/scripts.js"></script>
</body>
</html>