<?php
include("db.php");

$categoryQuery = "SELECT id, name FROM categories";
$categoryResult = $con->query($categoryQuery);

$productQuery = "SELECT id, name, price, image_url, category_id FROM menu_items";
$productResult = $con->query($productQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Digital Menu Manager Landing Page</title>
    <link rel="stylesheet" href="landing.css">
</head>
<body>
<header class="header" data-header>
    <div class="container">
        <div class="overlay" data-overlay></div>
<!--        <a href="#" class="logo">-->
<!--            <img src="./assets/images/logo.svg" alt="Digital Menu Logo">-->
<!--        </a>-->
<!--        <button class="menu-open-btn" data-menu-open-btn>-->
<!--            <ion-icon name="menu-outline"></ion-icon>-->
<!--        </button>-->
<!--        <nav class="navbar" data-navbar>-->
<!--            <button class="menu-close-btn" data-menu-close-btn>-->
<!--                <ion-icon name="close-outline"></ion-icon>-->
<!--            </button>-->
<!--            <a href="#" class="logo">-->
<!--                <img src="./assets/images/logo.svg" alt="Digital Menu Logo">-->
<!--            </a>-->
<!--            <ul class="navbar-list">-->
<!--                <li>-->
<!--                    <a href="#" class="navbar-link">Home</a>-->
<!--                </li>-->
<!--                <li>-->
<!--                    <a href="#about" class="navbar-link">About</a>-->
<!--                </li>-->
<!--                <li>-->
<!--                    <a href="#service" class="navbar-link">Service</a>-->
<!--                </li>-->
<!--            </ul>-->
<!--            <a href="registration.html">-->
<!--                <button class="btn btn-secondary">Get Started</button>-->
<!--            </a>-->
<!--        </nav>-->
    </div>
</header>

<main>
    <article>
        <!-- Services section-->
        <section id="service" class="services">
            <div class="container">
                <h2 class="h2 services-title">Here Is Your Food Menu 😋</h2>
                <div class="md-chips">
                    <div class="md-chip md-chip-clickable" data-category-id="all">All</div>
                    <?php
                    if ($categoryResult->num_rows > 0) {
                        while ($categoryRow = $categoryResult->fetch_assoc()) {
                            echo '<div class="md-chip md-chip-clickable" data-category-id="' . $categoryRow["id"] . '">';
                            echo $categoryRow["name"];
                            echo '</div>';
                        }
                    }
                    ?>
                </div>


                <ul class="services-list">
                    <?php
                    // Get tableId from the URL using $_GET['page']
                    $tableId = isset($_GET['page']) ? $_GET['page'] : null;

                    if ($productResult->num_rows > 0) {
                        while ($productRow = $productResult->fetch_assoc()) {
                            // Output HTML structure dynamically
                            echo '<li class="product" data-category-id="' . $productRow["category_id"] . '">';
                            echo '    <div class="services-card">';
                            echo '        <a href="#" class="card-banner">';
                            $imageData = $productRow['image_url'];
                            echo '            <img src="data:image/jpeg;base64,' . base64_encode($imageData) . '" alt="Uploaded Image" style="max-width: 500px;">';
                            echo '        </a>';
                            echo '        <a href="#" class="product-payment-link" data-table-id="' . $tableId . '" data-product-id="' . $productRow["id"] . '">';
                            echo '            <h3 class="h3 card-title">' . $productRow["name"] . '</h3>';
                            echo '        </a>';
                            echo '        <p class="card-text">Ksh ' . $productRow["price"] . '</p>';
                            echo '<button class="btn btn-secondary" id="payBtn_' . $productRow["id"] . '" onclick="openModal(' . $tableId . ')">Pay</button>';
                            echo '    </div>';
                            echo '</li>';
                        }
                    } else {
                        echo "0 results";
                    }
                    ?>
                </ul>
            </div>
            <div id="paymentModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <form id="paymentForm">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required>
                        <label for="phoneNumber">Phone Number:</label>
                        <input type="text" id="phoneNumber" name="phoneNumber" required>

                        <button type="button" onclick="processPayment()">Pay</button>
                    </form>
                </div>
            </div>

        </section>
    </article>
</main>

<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-brand">
                <a href="#" class="logo">
                    <img src="./assets/images/logo.svg" alt="Digital Menu logo">
                </a>
                <p class="footer-text">
                    We value our customers' time and we don't want them to be bothered when we have their menu ready from QR scan and ready to order from the comfort of their table!
                </p>
                <ul class="social-list">
                    <li>
                        <a href="#" class="social-link">
                            <ion-icon name="logo-google"></ion-icon>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="social-link">
                            <ion-icon name="logo-twitter"></ion-icon>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="social-link">
                            <ion-icon name="logo-instagram"></ion-icon>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="social-link">
                            <ion-icon name="logo-linkedin"></ion-icon>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="footer-link-box">
                <ul class="footer-list">
                    <li>
                        <p class="footer-link-title">Company</p>
                    </li>
                    <li>
                        <a href="#" class="footer-link">About</a>
                    </li>
                    <li>
                        <a href="#" class="footer-link">Terms</a>
                    </li>
                    <li>
                        <a href="#" class="footer-link">Privacy Policy</a>
                    </li>
                </ul>
                <ul class="footer-list">
                    <li>
                        <p class="footer-link-title">Contact</p>
                    </li>
                    <li class="contact-item">
                        <span>Call : </span>
                        <a href="tel:254763453453" class="contact-link">+254763453453</a>
                    </li>
                    <li class="contact-item">
                        <span>Email : </span>
                        <a href="mailto:digimenuleyian@gmail.com" class="contact-link">digimenuleyian@gmail.com</a>
                    </li>
                    <li class="contact-item">
                        <span>Address : </span>
                        <a href="#" class="contact-link">
                            <address>Nairobi, Kenya</address>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p class="copyright">
                &copy; 2024 <a href="">Leyian Digital Menu</a>. All right reserved
            </p>
        </div>
    </div>
</footer>

<script src="landing.js"></script>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script>
    var modal = document.getElementById("paymentModal");
    var span = document.getElementsByClassName("close")[0];

    function openModal() {
        modal.style.display = "block";
        var modalContent = document.querySelector(".modal-content");
        modalContent.innerHTML = "Table ID: " + tableId;
    }

    function closeModal() {
        modal.style.display = "none";
    }

    span.onclick = closeModal;

    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }

    function processPayment() {

        var urlParams = new URLSearchParams(window.location.search);

        // Get tableId from the URL
        var tableId = urlParams.get('table');
        console.log(tableId)

        var phoneNumber = document.getElementById("phoneNumber").value;


        var xhr = new XMLHttpRequest();
        xhr.open("POST", "process_payment.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                window.location.href = 'success.html';
                closeModal();
            }
        };

        // Send the data to the PHP file i.e process_payment.php
        xhr.send("phoneNumber=" + phoneNumber + "&tableId=" + tableId);
    }
</script>

<script>
    // JavaScript for filtering products based on category chips
    document.addEventListener('DOMContentLoaded', function () {
        var categoryChips = document.querySelectorAll('.md-chip-clickable');
        var productItems = document.querySelectorAll('.product');

        categoryChips.forEach(function (chip) {
            chip.addEventListener('click', function () {
                var categoryId = this.getAttribute('data-category-id');

                // Hide all products
                productItems.forEach(function (item) {
                    item.style.display = 'none';
                });

                // Show products based on selected category
                if (categoryId === 'all') {
                    productItems.forEach(function (item) {
                        item.style.display = 'block';
                    });
                } else {
                    var filteredProducts = document.querySelectorAll('.product[data-category-id="' + categoryId + '"]');
                    filteredProducts.forEach(function (item) {
                        item.style.display = 'block';
                    });
                }
            });
        });
    });
</script>

</body>
</html>

<?php
$con->close();
?>
