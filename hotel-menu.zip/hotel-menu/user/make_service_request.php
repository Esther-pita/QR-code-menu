<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>User - Service Requests</title>
    <link rel="stylesheet" href="css/style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
            <span class="material-icons-outlined text-card">menu</span>
        </div>
        <div class="header-left text-card">
            <span class="material-icons-outlined">search</span>
        </div>
        <div class="header-right text-card">
            <span class="material-icons-outlined">notifications</span>
            <span class="material-icons-outlined">email</span>
            <span class="material-icons-outlined">account_circle</span>
        </div>
    </header>
    <!-- End Header -->

    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="sidebar-title">
            <div class="sidebar-brand text-card">
                <span class="material-icons-outlined">recycling</span> Waste Disposal System
            </div>
            <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
            <li class="sidebar-list-item">
                <a href="dashboard.php">
                    <span class="material-icons-outlined">dashboard</span> Dashboard
                </a>
            </li>
            <li class="sidebar-list-item">
                <a href="service_requests.php">
                    <span class="material-icons-outlined">request_quote</span> Service Requests
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="inquiries.php">
                    <span class="material-icons-outlined">notification_important</span> Inquiries
                </a>
            </li>
            <li class="sidebar-list-item">
                <a href="logout.php">
                    <span class="material-icons-outlined">logout</span> Logout
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>Make Service Request</h2>
        </div>

        <div class="container">
            <input type="checkbox" id="check"><br>
            <div class="login form">

                <form action="service_request_logic.php" method="post">
                    <input type="text" name="client_name" placeholder="Client Name" required/>
                    <input type="text" name="client_email" placeholder="Client Email">

                    <select name="waste_type" id="waste_type">
                        <option value="">Select Waste Type</option>
                        <option value="plastic">Plastic</option>
                        <option value="metal">Metal</option>
                        <option value="food">Food</option>
                        <option value="electronics">Electronics</option>
                    </select>

                    <input type="date" name="request_date" placeholder="Request Date">
                    <input type="text" name="location" placeholder="Enter your Location/Estate">


                    <input type="submit" name="submit" class="button" value="Submit Inquiry">
                </form>

            </div>

        </div>

    </main>
    <!-- End Main -->

</div>
<script src="js/scripts.js"></script>
</body>
</html>
