<?php
include("../auth_session.php");
include("../db.php");

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if (isset($_REQUEST['save'])) {
    // Get the user's ID from the session
    $loggedInUser = $_SESSION['user_id'];

    // Remove backslashes
    $client_name = stripslashes($_REQUEST['client_name']);
    // Escape special characters in a string
    $client_name = mysqli_real_escape_string($con, $client_name);

    $client_email = stripslashes($_REQUEST['client_email']);
    $client_email = mysqli_real_escape_string($con, $client_email);

    $message = stripslashes($_REQUEST['message']);
    $message = mysqli_real_escape_string($con, $message);

    // Insert the inquiry data with the user ID
    $query = "INSERT INTO `inquiries` (client_name, client_email, message, user_id)
              VALUES ('$client_name', '$client_email', '$message', '$loggedInUser')";

    $result = mysqli_query($con, $query);
    if ($result) {
        header("Location: menu_category.php");
    } else {
        echo "<div class='form'>
                  <h3>Error saving inquiry.</h3><br/>
                  <p class='link'>Click here to <a href='makeinquiry.php'>try</a> again.</p>
              </div>";
    }
} else {
    // Handle the case when the form is not submitted
}
?>
