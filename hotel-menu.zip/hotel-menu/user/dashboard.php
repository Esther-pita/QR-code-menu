<?php
session_start();
include("../db.php");

$user_id = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - User area</title>
    <link rel="stylesheet" href="../style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <?php include 'header.php'; ?>
    <!-- End Header -->

    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="sidebar-title">
            <div class="sidebar-brand text-card">
                <span class="material-icons-outlined">recycling</span> Waste Disposal System
            </div>
            <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
            <li class="sidebar-list-item">
                <a href="dashboard.php">
                    <span class="material-icons-outlined">dashboard</span> Dashboard
                </a>
            </li>
            <li class="sidebar-list-item">
                <a href="service_requests.php">
                    <span class="material-icons-outlined">request_quote</span> Service Requests
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="inquiries.php">
                    <span class="material-icons-outlined">notification_important</span> Inquiries
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="logout.php">
                    <span class="material-icons-outlined">logout</span> Logout
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>User Dashboard</h2>
        </div>

        <div class="main-cards">
            <?php
            include ('../db.php');

            $cards = [
                [
                    'title' => 'My Service Requests',
                    'icon' => 'request_quote',
                    'table' => 'service_requests',
                ],
                [
                    'title' => 'My Inquiries',
                    'icon' => 'notification_important',
                    'table' => 'inquiries',
                ],
            ];

            foreach ($cards as $card) {
                $query = "SELECT COUNT(*) AS count FROM " . $card['table'] . " WHERE user_id = '$user_id'";
                $result = $con->query($query);

                if ($result) {
                    $row = $result->fetch_assoc();
                    $count = $row['count'];

                    echo '<div class="card">
                <a href="' . $card['table'] . '.php">
                    <div class="card-inner">
                        <h3 class="text-card">' . $card['title'] . '</h3>
                        <span class="material-icons-outlined icons">' . $card['icon'] . '</span>
                    </div>
                    <h1 class="text-num">' . $count . '</h1>
                </a>
              </div>';
                } else {
                    echo "Error: " . $con->error;
                }
            }

            $con->close();
            ?>
        </div>


    </main>
    <!-- End Main -->

</div>

<?php
$conn->close();
?>
<script src="../scripts.js"></script>
</body>
</html>
