<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>User - Inquiries</title>
    <link rel="stylesheet" href="css/style.css"/>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>
<div class="grid-container">

    <!-- Header -->
    <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
            <span class="material-icons-outlined text-card">menu</span>
        </div>
        <div class="header-left text-card">
            <span class="material-icons-outlined">search</span>
        </div>
        <div class="header-right text-card">
            <span class="material-icons-outlined">notifications</span>
            <span class="material-icons-outlined">email</span>
            <span class="material-icons-outlined">account_circle</span>
        </div>
    </header>
    <!-- End Header -->

    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="sidebar-title">
            <div class="sidebar-brand text-card">
                <span class="material-icons-outlined">recycling</span> Waste Disposal System
            </div>
            <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
            <li class="sidebar-list-item">
                <a href="dashboard.php">
                    <span class="material-icons-outlined">dashboard</span> Dashboard
                </a>
            </li>
            <li class="sidebar-list-item">
                <a href="service_requests.php">
                    <span class="material-icons-outlined">request_quote</span> Service Requests
                </a>
            </li>

            <li class="sidebar-list-item">
                <a href="inquiries.php">
                    <span class="material-icons-outlined">notification_important</span> Inquiries
                </a>
            </li>
            <li class="sidebar-list-item">
                <a href="logout.php">
                    <span class="material-icons-outlined">logout</span> Logout
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar -->

    <!-- Main -->
    <main class="main-container">
        <div class="main-title">
            <h2>Inquiries</h2>
            <a href="makeinquiry.php">
                <button class="button">
                    Make an Inquiry
                </button>
            </a>

        </div>

        <div class="table-container">
            <table class="content-table">
                <thead>
                <tr>
                    <th>Client Name</th>
                    <th>Client Email</th>
                    <th>Message</th>
                </tr>
                </thead>
                <tbody>
                <?php
                include("../db.php");
                include("../auth_session.php");


                $user_id = $_SESSION['user_id'];
                $query = "SELECT * FROM inquiries WHERE user_id = '$user_id'";
                // Fetch inquiries from the database
                $result = mysqli_query($con, $query);

                // Check if there are any inquiries
                if (mysqli_num_rows($result) > 0) {
                    // Output each inquiry as a table row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['client_name'] . "</td>";
                        echo "<td>" . $row['client_email'] . "</td>";
                        echo "<td>" . $row['message'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No inquiries found.</td></tr>";
                }

                // Close the database connection
                mysqli_close($con);
                ?>
                </tbody>
            </table>
        </div>
    </main>
    <!-- End Main -->
</div>
<script src="js/scripts.js"></script>
</body>
</html>

</div>

    </main>
    <!-- End Main -->

</div>
<script src="js/scripts.js"></script>
</body>
</html>
