<?php
include("../auth_session.php");
include("../db.php");

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    // Get the user's ID from the session
    $loggedInUser = $_SESSION['user_id'];

    $client_name = mysqli_real_escape_string($con, $_POST['client_name']);
    $client_email = mysqli_real_escape_string($con, $_POST['client_email']);
    $waste_type = mysqli_real_escape_string($con, $_POST['waste_type']);
    $request_date = mysqli_real_escape_string($con, $_POST['request_date']);
    $location = mysqli_real_escape_string($con, $_POST['location']);

    // Validate email format
    if (!filter_var($client_email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format. Please enter a valid email address.";
        exit();
    }

    // Validate date format (you can add more specific validation if needed)
    if (!strtotime($request_date)) {
        echo "Invalid date format. Please enter a valid date.";
        exit();
    }

    $query = "INSERT INTO `service_requests` (client_name, client_email, waste_type, request_date, location, user_id)
              VALUES ('$client_name', '$client_email', '$waste_type', '$request_date', '$location', '$loggedInUser')";

//    echo $query;

    $result = mysqli_query($con, $query);

    if ($result) {
        header("Location: service_requests.php");
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>