<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    $message = "You need to sign in to access the page you were trying to access.";

    $encodedMessage = urlencode($message);
    header("Location: ../signin.html?message=$encodedMessage");
    exit();
}

?>